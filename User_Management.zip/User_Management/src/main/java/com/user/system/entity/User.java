package com.user.system.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.user.system.dto.UserDto;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userId;
    private String email;
    private String name;
    @JsonIgnore
    private String password;
    private LocalDateTime lastLogin;

    public static UserDto prepareEntity(User user) {
        UserDto userDto=new UserDto();
        userDto.setName(user.getName());
        userDto.setEmail(user.getEmail());
        userDto.setPassword(user.getPassword());
        userDto.setLastLogin(LocalDateTime.now());
        return userDto;
    }
}

