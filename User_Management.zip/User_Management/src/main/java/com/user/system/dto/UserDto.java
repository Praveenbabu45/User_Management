package com.user.system.dto;

import com.user.system.entity.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UserDto {
    @Email(message = "Email should be in valid format")
    private String email;
    @NotBlank(message = "Missing Name")
    private String name;
    @NotBlank(message = "Missing Password")
    private String password;
    private LocalDateTime lastLogin;

    public static User prepareEntity(UserDto userDto) {
        User user=new User();
        user.setName(userDto.getName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setLastLogin(LocalDateTime.now());
        return user;
    }
}
