package com.user.system.service;

import com.user.system.dto.UserDto;
import com.user.system.entity.User;
import com.user.system.exceptions.NoUserFoundException;
import com.user.system.exceptions.NullIdException;
import com.user.system.exceptions.ResourceNotFoundException;
import com.user.system.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;

    public User getUserdetails(Integer id) {
        return userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
    }

    public User createUser(UserDto userDto) {
        User existed=userRepository.findByEmail(userDto.getEmail());
        if(existed!=null){
            throw new NullIdException("Cannot Create User As Already Existed with same email " + existed.getEmail() + " for name - "+existed.getName());
        }
        return userRepository.save(UserDto.prepareEntity(userDto));
    }
    public List<User> createUsers(List<UserDto> userDtos) {
        List<User> userList = userDtos.stream()
                .map(UserDto::prepareEntity)
                .toList();
        return userRepository.saveAll(userList);
    }

    public User updateUser(Integer id,User user) {

        User existingUser = userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + id));
        existingUser.setName(user.getName());
        existingUser.setEmail(user.getEmail());
        existingUser.setPassword(user.getPassword());
        existingUser.setLastLogin(LocalDateTime.now());

        // Save the updated user back to the db
        userRepository.save(existingUser);
        return existingUser;
    }

    public String deleteUser(Integer id) {
        User user = userRepository.findById(id).orElse(null);
        if(user == null)
            throw new ResourceNotFoundException("User not found with id " + id);
        userRepository.delete(user);
        return "User details for "+user.getName()+" with id- "+ id + " deleted successfully";
    }

    public List<User> listUsers() {
        List<User> users=userRepository.findAll();
        if(users.isEmpty()){
            throw new ResourceNotFoundException("Not found any Users");
        }
        return users;

    }

    public String deleteAllUsers() {
        userRepository.deleteAll();
        return "All users were deleted";
    }
@Transactional
    public String deleteAllUsersByIds(List<Integer> ids) {
        try {
            userRepository.deleteAllById(ids);
            return "Selected users have been deleted";
        }
        catch (InvalidDataAccessApiUsageException ex) {
            System.out.println("___________________________________________________________________");
            throw new NullIdException("error occurred while deleting users, Cannot pass null Id's");
        }

    }

    public List<User> getUserDetailsByName(String name) {
        List<User> userList=userRepository.findByName(name);
        if(userList.isEmpty()){
            throw new NoUserFoundException("No Users found with given name - "+ name);
        }
        return userList;
    }

    public List<User> getUserDetailsByNameStartsWith(String name) {
        List<User> userList=userRepository.findByNameStartingWith(name);
        if(userList.isEmpty()){
            throw new NoUserFoundException("No Users found with given name starts with- "+ name);
        }
        return userList;
    }

    public User getUserDetailsByEmail(String email) {
        User user=userRepository.findByEmail(email);

        if(user==null){
            throw new NoUserFoundException("No Users found with given Email - "+ email);
        }
        return user;
    }

    public boolean authenticate(String email, String password) {
        User existed = userRepository.findByEmail(email);
        if (existed!=null) {
            return password.equals(existed.getPassword());
        }
        return false;
    }
    }

