package com.user.system.controller;

import com.user.system.dto.LoginDto;
import com.user.system.dto.UserDto;
import com.user.system.entity.User;
import com.user.system.service.UserService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/management")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<String> loginviaForm_Data(@RequestParam String email, @RequestParam String password) {
        boolean isAuthenticated = userService.authenticate(email, password);
        if (isAuthenticated) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        }
    }

    @PostMapping("/requestbody/login")
    public ResponseEntity<String> login(@Valid @RequestBody LoginDto loginDto) {
        boolean isAuthenticated = userService.authenticate(loginDto.getEmail(), loginDto.getPassword());
        if (isAuthenticated) {
            return new ResponseEntity<>("Login successful",HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid email or password",HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable Integer id) {
        return new ResponseEntity<User>(userService.getUserdetails(id),HttpStatus.OK);
    }
    @GetMapping("/byName/{name}")
    public ResponseEntity<List<User>> getUsersByName(@PathVariable String name) {
        return new ResponseEntity<List<User>>(userService.getUserDetailsByName(name),HttpStatus.OK);
    }
    @GetMapping("/byEmail/{name}")
        public ResponseEntity<User> getUsersByEmail(@PathVariable @Email String email) {
        return new ResponseEntity<User>(userService.getUserDetailsByEmail(email),HttpStatus.OK);
    }
    @GetMapping("/byNameStartsWith/{name}")
    public ResponseEntity<List<User>> getUsersByNameStartsWith(@PathVariable String name) {
        return new ResponseEntity<List<User>>(userService.getUserDetailsByNameStartsWith(name),HttpStatus.OK);
    }
    @GetMapping
    public ResponseEntity<List<User>> listUsers() {
        return new ResponseEntity<List<User>>(userService.listUsers(),HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<User> createUser(@Valid @RequestBody UserDto userDto) {
        User user=userService.createUser(userDto);
        return new ResponseEntity<User>(user,HttpStatus.CREATED);
    }
    @PostMapping("/create/all")
    public ResponseEntity<List<User>> createUsers(@RequestBody List<UserDto> userDtos) {
        List<User> users=userService.createUsers(userDtos);
        return new ResponseEntity<List<User>>(users,HttpStatus.CREATED);
    }
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Integer id, @RequestBody User user) {
        User updatedUser=userService.updateUser(id, user);
        return new ResponseEntity<User>(updatedUser,HttpStatus.CREATED);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Integer id) {
        String response =userService.deleteUser(id);
        return new ResponseEntity<String>(response,HttpStatus.OK);
    }
    @DeleteMapping("/deleteAll")
    public ResponseEntity<String> deleteAllUsers() {
        String response =userService.deleteAllUsers();
        return new ResponseEntity<String>(response,HttpStatus.OK);
    }
    @DeleteMapping("/deleteAllByIds")
    public ResponseEntity<String> deleteAllUsersByIds(@RequestBody List<Integer> ids) {
        String response = userService.deleteAllUsersByIds(ids);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}